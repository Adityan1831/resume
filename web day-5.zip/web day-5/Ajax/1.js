'use strict'
document.getElementById('btn1').addEventListener('click', function () {
    // alert("button 1 clicked")
    var xmlhttp = new XMLHttpRequest
    console.log(xmlhttp)
    console.log(xmlhttp.readyState)
    // if 0- request not intialization, 1- request is in progress, 2- request is done, 3- request is receiving response, 4- request is done
    console.log(xmlhttp.status)
    xmlhttp.onreadystatechange = function () {
        console.log(xmlhttp.readyState, xmlhttp.status)
        if (xmlhttp.readyState ==4 && xmlhttp.status == 200) {
            console.log(xmlhttp.responseText)
            var res= JSON.parse(xmlhttp.responseText)
            console.log(res)
            res && res.length>0 && res.forEach(function(v,i){
                console.log(v,i)
                var divtag =document.createElement('div')
                var imgtag = document.createElement('img')
                var h2tag = document.createElement('h2')
                var ptag = document.createElement('p')

                imgtag.src = v.image
                h2tag.innerHTML=v.price;
                ptag.innerHTML=v.title;
                divtag.className='col-3 text center'
                imgtag.className='img-fluid'
                divtag.append(imgtag,h2tag,ptag)
                
                document.querySelector('#row').append(divtag)
            })

        }
        // 1 works when open method initiated and its request has been setup

    }
    xmlhttp.open('get', "https://fakestoreapi.com/products")
    //this method will help to perform a feaching data from the server
    xmlhttp.send()
    //2- is send request to the server readystate will become 2
    //3 - request it is in progesss mode
    //4 - request cycle  completed 

});